//
//  MgmntCollectionViewCell.swift
//  DaddysKitchen
//
//  Created by Manpreet Kaur Gill on 2019-07-23.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class MgmntCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgViewMgmnt: UIImageView!
    
}
