//
//  MgmntViewController.swift
//  DaddysKitchen
//
//  Created by Manpreet Kaur Gill on 2019-07-23.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class MgmntViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var collectionViewMgmnt: UICollectionView!
    
    var arrMgmnt = ["f1", "f2", "f3", "f4", "f5", "f6"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionViewMgmnt.delegate = self
        self.collectionViewMgmnt.dataSource = self

        // Do any additional setup after loading the view.
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrMgmnt.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionViewMgmnt.dequeueReusableCell(withReuseIdentifier: "mgmntRow", for: indexPath) as! MgmntCollectionViewCell
        
        cell.imgViewMgmnt.image = UIImage(named: arrMgmnt[indexPath.row])
        
        return cell
        
    }
    

}
