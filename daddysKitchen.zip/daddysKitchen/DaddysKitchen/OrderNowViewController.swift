//
//  OrderNowViewController.swift
//  DaddysKitchen
//
//  Created by MacStudent on 2019-07-24.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class OrderNowViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    @IBOutlet weak var tableViewMenu: UITableView!
    
    let arrImages = ["1", "2", "3", "4", "5"]
    let arrPrice = ["15", "12", "11", "10", "11"]
    let arrName = ["Butter Chicken", "Chicken kebab", "kalmi kebab", "Shahi Paneer", "Dal Makhani"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableViewMenu.delegate = self
        self.tableViewMenu.dataSource = self
        

        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrImages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableViewMenu.dequeueReusableCell(withIdentifier: "menuRow", for: indexPath) as! OrderNowTableViewCell
        cell.imgViewMenu.image = UIImage(named: arrImages[indexPath.row])
        cell.labelName.text = arrName[indexPath.row]
        cell.labelPrice.text = "$\(arrPrice[indexPath.row])"
        
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    @IBAction func btnPressedOrderNow(_ sender: Any) {
        
        let alert = UIAlertController(title: "Daddy's Kitchen", message: "Order successful", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default) {
            UIAlertAction in
            
            self.navigationController?.popViewController(animated: true)
            
        }
        alert.addAction(okAction)
        //            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    

}
