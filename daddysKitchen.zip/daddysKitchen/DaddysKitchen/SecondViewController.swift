//
//  SecondViewController.swift
//  DaddysKitchen
//
//  Created by MacStudent on 2019-07-22.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

}
