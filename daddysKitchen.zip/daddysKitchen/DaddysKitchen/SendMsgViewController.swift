//
//  SendMsgViewController.swift
//  DaddysKitchen
//
//  Created by MacStudent on 2019-07-24.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit
import MessageUI

class SendMsgViewController: UIViewController {

    @IBOutlet weak var textFieldPhn: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnPressedSubmit(_ sender: Any) {
        if (MFMessageComposeViewController.canSendText()) {
            let controller = MFMessageComposeViewController()
            controller.body = "Message Body"
            controller.recipients = [textFieldPhn.text] as? [String]
            controller.messageComposeDelegate = self as? MFMessageComposeViewControllerDelegate
            self.present(controller, animated: true, completion: nil)
        }
        
    }
    
}
