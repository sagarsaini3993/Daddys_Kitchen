//
//  StaffViewController.swift
//  DaddysKitchen
//
//  Created by Manpreet Kaur Gill on 2019-07-23.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit

class StaffViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    
    @IBOutlet weak var collectionViewStaff: UICollectionView!
    @IBOutlet weak var collectionViewManagement: UICollectionView!
    
    var arrMaleStaffPics = ["m1", "m2", "m3", "m4", "m5", "m6"]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionViewStaff.dataSource = self
        self.collectionViewStaff.delegate = self
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return arrMaleStaffPics.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
            let cell = collectionViewStaff.dequeueReusableCell(withReuseIdentifier: "staffRow", for: indexPath) as! StaffCollectionViewCell
            cell.imgViewStaffPictures.image = UIImage(named: arrMaleStaffPics[indexPath.row])
            return cell
        
    }

}
